/* @description: GUI for Server Settings
 * @authors: Akif Batur, Nashiha Ahmed
 * @version: 1 (date: 03.08.16)
 */

package tr.com.bilisim.cnc.server;

public class ServerGui
{	
	public static void main(String[] args)
	{
		
	}
}
